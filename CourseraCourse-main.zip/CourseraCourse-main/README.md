# CourseraCourse
Introduction to Git Hub Coursera Course Assignment 
I am editing the README file. Adding some more details about the project description.
