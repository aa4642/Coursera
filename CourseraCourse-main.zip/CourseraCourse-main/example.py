def git_opeation():
 print("I am adding example.py file to the remote repository.")
git_opeation()
